const form = document.getElementById("myForm");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  // Clear errors
  ["name", "email", "password", "age", "gender", "address", "salary"].forEach(id => {
    document.getElementById(id + "Error").textContent = "";
  });

  // Get values
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const age = document.getElementById("age").value;
  const gender = document.getElementById("gender").value;
  const address = document.getElementById("address").value.trim();
  const salary = document.getElementById("salary").value;

  let isValid = true;

  if (name === "") {
    document.getElementById("nameError").textContent = "Name is required.";
    isValid = false;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    document.getElementById("emailError").textContent = "Enter a valid email.";
    isValid = false;
  }

  const passwordErrors = [];
  if (password.length < 8) {
    passwordErrors.push("at least 8 characters");
  }
  if (!/[A-Z]/.test(password)) {
    passwordErrors.push("an uppercase letter");
  }
  if (!/[a-z]/.test(password)) {
    passwordErrors.push("a lowercase letter");
  }
  if (!/[0-9]/.test(password)) {
    passwordErrors.push("a number");
  }
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    passwordErrors.push("a special character");
  }
  
  if (passwordErrors.length > 0) {
    document.getElementById("passwordError").textContent =
      "Password must contain " + passwordErrors.join(", ") + ".";
    isValid = false;
  }
  

  if (age === "" || age <= 0) {
    document.getElementById("ageError").textContent = "Enter a valid age.";
    isValid = false;
  }

  if (gender === "") {
    document.getElementById("genderError").textContent = "Select your gender.";
    isValid = false;
  }

  if (address === "") {
    document.getElementById("addressError").textContent = "Address is required.";
    isValid = false;
  }

  if (salary === "" || salary <= 0) {
    document.getElementById("salaryError").textContent = "Enter a valid salary.";
    isValid = false;
  }

  if (isValid) {
    const formData = {
      name,
      email,
      password,
      age,
      gender,
      address,
      salary,
    };
    console.log("Form Submitted:", formData);
    alert("Form submitted successfully!");
    form.reset();
  }
});
