import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {

    // JDBC Database URL, username, and password
    private static final String URL = "jdbc:mysql://localhost:3306/emp";
    private static final String USER = "root";
    private static final String PASSWORD = "root"; // Change as per your setup

    // Database Connection
    private Connection connect() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC Driver not found.", e);
        }
    }

    // Create a new employee
    private void createEmployee(String name, double salary) throws SQLException {
        String query = "INSERT INTO Employee (name, salary) VALUES (?, ?)";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setDouble(2, salary);
            stmt.executeUpdate();
        }
    }

    // Get employee salary by name
    private double getEmployeeSalary(String name) throws SQLException {
        String query = "SELECT salary FROM Employee WHERE name = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("salary");
            }
        }
        return -1; // Employee not found
    }

    // Update employee salary by name
    private void updateEmployeeSalary(String name, double salary) throws SQLException {
        String query = "UPDATE Employee SET salary = ? WHERE name = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDouble(1, salary);
            stmt.setString(2, name);
            stmt.executeUpdate();
        }
    }

    // Delete employee by name
    private void deleteEmployee(String name) throws SQLException {
        String query = "DELETE FROM Employee WHERE name = ?";
        try (Connection conn = connect(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.executeUpdate();
        }
    }

    // Process the form submission
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("create".equals(action)) {
                String name = request.getParameter("name");
                double salary = Double.parseDouble(request.getParameter("salary"));
                createEmployee(name, salary);
                response.getWriter().write("Employee Created Successfully!");

            } else if ("update".equals(action)) {
                String name = request.getParameter("name");
                double salary = Double.parseDouble(request.getParameter("salary"));
                updateEmployeeSalary(name, salary);
                response.getWriter().write("Employee Salary Updated!");

            } else if ("delete".equals(action)) {
                String name = request.getParameter("name");
                deleteEmployee(name);
                response.getWriter().write("Employee Deleted!");

            } else if ("get".equals(action)) {
                String name = request.getParameter("name");
                double salary = getEmployeeSalary(name);
                if (salary == -1) {
                    response.getWriter().write("Employee Not Found");
                } else {
                    response.getWriter().write("Employee Salary: " + salary);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database Error: " + e.getMessage());
        }
    }
}
