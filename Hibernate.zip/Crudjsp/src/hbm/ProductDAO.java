package hbm;

import java.util.List;
import org.hibernate.*;

public class ProductDAO {
    public void save(Product p) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(p);
        session.getTransaction().commit();
        session.close();
    }

    public void update(Product p) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.update(p);
        session.getTransaction().commit();
        session.close();
    }

    public void delete(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Product p = session.get(Product.class, id);
        if (p != null) session.delete(p);
        session.getTransaction().commit();
        session.close();
    }

    public Product get(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Product p = session.get(Product.class, id);
        session.close();
        return p;
    }

    public List<Product> getAll() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Product> list = session.createQuery("from Product", Product.class).list();
        session.close();
        return list;
    }
}
