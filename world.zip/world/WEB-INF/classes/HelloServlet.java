import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;

@WebServlet("/world")
public class HelloServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
        res.setContentType("text/html");
            PrintWriter out = res.getWriter();
        out.println("<h1>Hello from Jakarta Servlet!</h1>");
    }
   
}
